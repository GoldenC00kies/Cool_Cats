let x = 100;
let y = 100;
let vx = 2;
let vy = 2;

function setup() {
	createCanvas(windowWidth, windowHeight);
	frameRate(2)
	
}



function draw() {
	for (var i = 0; i < 10; i += 1){ 
		for (var j = 0; j < 8; j += 1){ 
			ellipse(200 + (i * 70),100 + (j * 70),50);
			background(y,x,Math.ceil(Math.random() * 360));
			if (x < 0 || x > width){
				vx = -vx;
	}
	if (y < 0 || y > height){
		vy = -vy;
	}
	
	x += vx;
	y += vy;
			fill(y/2, x/2, 200)
			ellipse(x,y,200,); 
		
	
}
	}
}